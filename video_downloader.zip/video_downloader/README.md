# Multi-Platform Video Downloader

A comprehensive web application for downloading videos from TikTok, Instagram, Facebook, and YouTube without watermarks.

## Features

- **Multi-Platform Support**: Download videos from TikTok, Instagram, Facebook, and YouTube
- **No Watermarks**: Get clean videos without platform watermarks (where supported)
- **Modern Web Interface**: Beautiful, responsive design that works on desktop and mobile
- **Fast Processing**: Quick video information retrieval and download links
- **Safe & Secure**: No data storage, privacy-focused approach

## Supported Platforms

### ✅ TikTok
- Full download support with no watermarks
- HD quality when available
- Video metadata (title, author, duration)

### ⚠️ YouTube
- Video information retrieval
- Note: Full download requires yt-dlp integration

### ⚠️ Instagram
- Basic URL detection
- Note: Requires specialized API integration for downloads

### ⚠️ Facebook
- Basic URL detection  
- Note: Requires specialized API integration for downloads

## Installation & Setup

1. **Clone or extract the project**
   ```bash
   cd video_downloader
   ```

2. **Activate virtual environment**
   ```bash
   source venv/bin/activate
   ```

3. **Install dependencies** (if needed)
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python run_app.py
   ```

5. **Access the app**
   Open your browser and go to: `http://localhost:5001`

## Usage

1. Open the web application in your browser
2. Paste a video URL from any supported platform
3. Click "Download Video" 
4. View video information and download link (if available)

## Technical Details

### Backend (Flask)
- **Framework**: Flask with CORS support
- **API Endpoints**: 
  - `POST /api/download` - Process video URLs
  - `GET /api/supported-platforms` - Get platform information
- **Dependencies**: Flask, Flask-CORS, requests

### Frontend (HTML/CSS/JavaScript)
- **Responsive Design**: Works on desktop and mobile
- **Modern UI**: Gradient backgrounds, smooth animations
- **Platform Icons**: Visual indicators for each supported platform
- **Real-time Feedback**: Loading states and error handling

### Video Processing
- **TikTok**: Uses tikwm.com API for watermark-free downloads
- **YouTube**: Uses oEmbed API for video information
- **Instagram/Facebook**: Placeholder implementation (requires API integration)

## File Structure

```
video_downloader/
├── src/
│   ├── routes/
│   │   ├── video_downloader.py    # Main video processing logic
│   │   └── user.py               # User management (template)
│   ├── models/
│   │   └── user.py               # Database models
│   ├── static/
│   │   └── index.html            # Frontend interface
│   ├── database/
│   │   └── app.db               # SQLite database
│   └── main.py                  # Main Flask application
├── venv/                        # Virtual environment
├── run_app.py                   # Alternative app runner
├── requirements.txt             # Python dependencies
└── README.md                   # This file
```

## API Documentation

### POST /api/download
Download or get information about a video.

**Request Body:**
```json
{
  "url": "https://www.tiktok.com/@user/video/1234567890"
}
```

**Response:**
```json
{
  "success": true,
  "platform": "tiktok",
  "title": "Video Title",
  "author": "Username",
  "duration": 30,
  "download_url": "https://...",
  "thumbnail": "https://..."
}
```

### GET /api/supported-platforms
Get list of supported platforms and their capabilities.

**Response:**
```json
{
  "platforms": [
    {
      "name": "TikTok",
      "key": "tiktok", 
      "supported_features": ["download", "no_watermark", "hd_quality"]
    }
  ]
}
```

## Development Notes

- The application is currently configured for development use
- For production deployment, use a proper WSGI server like Gunicorn
- TikTok downloads use a third-party API (tikwm.com)
- YouTube, Instagram, and Facebook require additional API integrations for full functionality

## Future Enhancements

1. **YouTube Integration**: Add yt-dlp support for actual video downloads
2. **Instagram API**: Integrate with Instagram Basic Display API
3. **Facebook API**: Add Facebook Graph API integration  
4. **Download Management**: Add progress tracking and download history
5. **Quality Selection**: Allow users to choose video quality
6. **Batch Downloads**: Support multiple URLs at once

## License

This project is for educational purposes. Please respect the terms of service of each platform when downloading content.

## Disclaimer

This tool is intended for downloading content that you have the right to download. Please respect copyright laws and platform terms of service.

