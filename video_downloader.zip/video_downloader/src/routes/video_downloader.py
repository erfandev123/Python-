from flask import Blueprint, request, jsonify
import requests
import re
import json
import os
import tempfile
import yt_dlp
import instaloader
from urllib.parse import urlparse

video_downloader_bp = Blueprint('video_downloader', __name__)

def extract_video_id_from_url(url, platform):
    """Extract video ID from different platform URLs"""
    if platform == 'tiktok':
        # TikTok URL patterns
        patterns = [
            r'tiktok\.com/@[^/]+/video/(\d+)',
            r'vm\.tiktok\.com/([A-Za-z0-9]+)',
            r'tiktok\.com/t/([A-Za-z0-9]+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
    elif platform == 'youtube':
        # YouTube URL patterns
        patterns = [
            r'youtube\.com/watch\?v=([A-Za-z0-9_-]+)',
            r'youtu\.be/([A-Za-z0-9_-]+)',
            r'youtube\.com/embed/([A-Za-z0-9_-]+)',
            r'youtube\.com/shorts/([A-Za-z0-9_-]+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
    elif platform == 'instagram':
        # Instagram URL patterns
        patterns = [
            r'instagram\.com/p/([A-Za-z0-9_-]+)',
            r'instagram\.com/reel/([A-Za-z0-9_-]+)',
            r'instagram\.com/tv/([A-Za-z0-9_-]+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
    elif platform == 'facebook':
        # Facebook URL patterns
        patterns = [
            r'facebook\.com/watch/\?v=(\d+)',
            r'facebook\.com/[^/]+/videos/(\d+)',
            r'fb\.watch/([A-Za-z0-9]+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
    
    return None

def detect_platform(url):
    """Detect which platform the URL belongs to"""
    domain = urlparse(url).netloc.lower()
    
    if 'tiktok.com' in domain or 'vm.tiktok.com' in domain:
        return 'tiktok'
    elif 'youtube.com' in domain or 'youtu.be' in domain:
        return 'youtube'
    elif 'instagram.com' in domain:
        return 'instagram'
    elif 'facebook.com' in domain or 'fb.watch' in domain:
        return 'facebook'
    
    return None

def download_tiktok_video(url):
    """Download TikTok video using a free API"""
    try:
        # Using a free TikTok downloader API
        api_url = "https://tikwm.com/api/"
        
        response = requests.post(api_url, data={
            'url': url,
            'hd': 1
        })
        
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                video_data = data.get('data', {})
                return {
                    'success': True,
                    'download_url': video_data.get('hdplay') or video_data.get('play'),
                    'title': video_data.get('title', 'TikTok Video'),
                    'thumbnail': video_data.get('cover'),
                    'duration': video_data.get('duration'),
                    'author': video_data.get('author', {}).get('nickname', 'Unknown')
                }
        
        return {'success': False, 'error': 'Failed to fetch video data'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def download_youtube_video(url):
    """Download YouTube video using yt-dlp"""
    try:
        ydl_opts = {
            'format': 'best[height<=720]',  # Limit to 720p for faster downloads
            'noplaylist': True,
            'extract_flat': False,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Extract info without downloading
            info = ydl.extract_info(url, download=False)
            
            # Get the best format URL
            formats = info.get('formats', [])
            download_url = None
            
            # Find the best video format
            for fmt in reversed(formats):
                if fmt.get('vcodec') != 'none' and fmt.get('url'):
                    download_url = fmt.get('url')
                    break
            
            return {
                'success': True,
                'download_url': download_url,
                'title': info.get('title', 'YouTube Video'),
                'thumbnail': info.get('thumbnail'),
                'duration': info.get('duration'),
                'author': info.get('uploader', 'Unknown'),
                'view_count': info.get('view_count'),
                'upload_date': info.get('upload_date')
            }
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

def download_instagram_video(url):
    """Download Instagram video using instaloader"""
    try:
        # Extract shortcode from URL
        shortcode = extract_video_id_from_url(url, 'instagram')
        if not shortcode:
            return {'success': False, 'error': 'Invalid Instagram URL'}
        
        # Create instaloader instance
        L = instaloader.Instaloader()
        
        # Get post
        post = instaloader.Post.from_shortcode(L.context, shortcode)
        
        # Check if it's a video
        if post.is_video:
            return {
                'success': True,
                'download_url': post.video_url,
                'title': post.caption[:100] + '...' if post.caption and len(post.caption) > 100 else post.caption or 'Instagram Video',
                'thumbnail': post.url,
                'author': post.owner_username,
                'likes': post.likes,
                'date': post.date.isoformat() if post.date else None
            }
        else:
            return {'success': False, 'error': 'This post is not a video'}
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

def download_facebook_video(url):
    """Download Facebook video using yt-dlp"""
    try:
        ydl_opts = {
            'format': 'best',
            'noplaylist': True,
            'extract_flat': False,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Extract info without downloading
            info = ydl.extract_info(url, download=False)
            
            # Get the best format URL
            formats = info.get('formats', [])
            download_url = None
            
            # Find the best video format
            for fmt in reversed(formats):
                if fmt.get('vcodec') != 'none' and fmt.get('url'):
                    download_url = fmt.get('url')
                    break
            
            return {
                'success': True,
                'download_url': download_url,
                'title': info.get('title', 'Facebook Video'),
                'thumbnail': info.get('thumbnail'),
                'duration': info.get('duration'),
                'author': info.get('uploader', 'Unknown')
            }
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

@video_downloader_bp.route('/download', methods=['POST'])
def download_video():
    """Main endpoint for video download"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'success': False, 'error': 'URL is required'}), 400
        
        # Detect platform
        platform = detect_platform(url)
        if not platform:
            return jsonify({'success': False, 'error': 'Unsupported platform'}), 400
        
        # Download based on platform
        if platform == 'tiktok':
            result = download_tiktok_video(url)
        elif platform == 'youtube':
            result = download_youtube_video(url)
        elif platform == 'instagram':
            result = download_instagram_video(url)
        elif platform == 'facebook':
            result = download_facebook_video(url)
        else:
            return jsonify({'success': False, 'error': 'Platform not supported'}), 400
        
        result['platform'] = platform
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@video_downloader_bp.route('/supported-platforms', methods=['GET'])
def get_supported_platforms():
    """Get list of supported platforms"""
    return jsonify({
        'platforms': [
            {
                'name': 'TikTok',
                'key': 'tiktok',
                'supported_features': ['download', 'no_watermark', 'hd_quality']
            },
            {
                'name': 'YouTube',
                'key': 'youtube',
                'supported_features': ['download', 'hd_quality', 'metadata']
            },
            {
                'name': 'Instagram',
                'key': 'instagram',
                'supported_features': ['download', 'metadata']
            },
            {
                'name': 'Facebook',
                'key': 'facebook',
                'supported_features': ['download', 'metadata']
            }
        ]
    })

